<p align="center">
  <img src="brand/fluttergo_mark.png" alt="Flutter Go — anneau hexagonal et chevron ambre" width="104">
</p>

<h1 align="center">Flutter Go</h1>

<p align="center">
  <strong>Le poste de pilotage Flutter pour Windows.</strong><br>
  Détecter l'environnement, connecter un téléphone, lancer avec Hot&nbsp;Reload,
  partager l'APK par QR&nbsp;code — sans terminal.
</p>

<p align="center">
  <a href="LICENSE">Licence MIT</a> ·
  Flutter Go Desktop v0.11.0 ·
  CLI Dart 3.5+
</p>

---

## Ce que fait Flutter Go

Flutter produit vite, mais le cycle réel — installer le SDK, brancher un
téléphone, comprendre pourquoi rien n'apparaît, relancer la bonne commande —
reste la partie ingrate. Flutter Go s'occupe de ce cycle :

- **Diagnostic** : ce qui est installé, ce qui manque, et quoi faire pour
  chaque point bloquant.
- **Appareils** : téléphones en USB ou en Wi-Fi, y compris ceux qu'adb voit
  mais qui ne sont pas encore autorisés.
- **Exécution** : lancement du projet avec **Hot Reload automatique** et
  **Hot Restart** toujours accessibles.
- **Partage** : compilation d'un APK et installation sur un téléphone par
  **QR code**, sans store ni câble.
- **Équipe** : plusieurs développeurs sur un même appareil, journaux et
  fichiers synchronisés.

Deux entrées possibles, même moteur : **Flutter Go Desktop** (application
Windows) et le **CLI `fluttergo`** (terminal, Windows/macOS/Linux).

## Flutter Go Desktop — les écrans

| Écran | Ce qu'il fait |
|---|---|
| Tableau de bord | Où j'en suis, et quelle est la prochaine étape utile |
| Diagnostic | `fluttergo doctor --json` traduit : cause, conséquence, correction |
| Appareils | ce qu'adb confirme, transport (USB/Wi-Fi/émulateur), états bloqués |
| Projet Flutter | choisir un dossier, le valider, résoudre les dépendances, cibler |
| Connexion USB | parcours guidé et détection automatique |
| Connexion sans fil | appairage Android 11+ ou bascule TCP/IP après un USB |
| Partage APK | compilation, serveur local, QR code et test de joignabilité |
| Collaboration | `host` / `join`, adresse et jeton copiables |
| Console | toutes les opérations, filtrables et copiables |
| Paramètres | détection du CLI, chemin manuel vérifié, à propos |

La Desktop **pilote le CLI réel** : elle n'implémente pas Flutter à sa place
et ne modifie pas vos projets. `fluttergo` reste utilisable seul.

### Aperçu

_Images générées par le moteur Flutter depuis le code de l'application
(`gui/test/screenshots_generator.dart`), avec des données d'exemple._

| | |
|---|---|
| ![Tableau de bord](docs/screenshots/01-tableau-de-bord.png) | ![Diagnostic](docs/screenshots/02-diagnostic.png) |
| ![Appareils](docs/screenshots/03-appareils.png) | ![Projet Flutter](docs/screenshots/04-projet-flutter.png) |
| ![Connexion USB](docs/screenshots/05-connexion-usb.png) | ![Connexion sans fil](docs/screenshots/06-connexion-sans-fil.png) |
| ![Partage APK](docs/screenshots/07-partage-apk.png) | ![Collaboration](docs/screenshots/08-collaboration.png) |
| ![Console](docs/screenshots/09-console.png) | ![Paramètres](docs/screenshots/10-parametres.png) |

## Installation

> 📖 Manuel complet (installation, usage, dépannage) :
> [docs/MANUEL.md](docs/MANUEL.md)

### Windows — installateur (recommandé)

1. Téléchargez `FlutterGo-Setup-<version>.exe` depuis le
   [site Flutter Go](https://emstronglezin-cmd.github.io/fluttergo-site/) ou
   les [Releases GitHub](https://github.com/emstronglezin-cmd/fluttergo/releases).
2. Lancez l'installateur : installation **par utilisateur**, sans droits
   administrateur, dans `%LOCALAPPDATA%\Programs\FlutterGo`.
3. `fluttergo` est ajouté au **PATH utilisateur** automatiquement, et Flutter
   Go Desktop apparaît dans le Menu Démarrer (raccourci Bureau optionnel).
4. **Ouvrez un nouveau terminal**, puis vérifiez :

```powershell
fluttergo --version
fluttergo doctor
```

L'installateur installe **Flutter Go uniquement**. Les SDK (Flutter, Android,
Java) ne sont pas embarqués : `fluttergo doctor` les détecte et dit
précisément ce qui manque.

Une archive `FlutterGo-Portable-<version>.zip` (CLI + Flutter Go Desktop,
sans installation) est publiée à chaque release.

### Prérequis réels

| Outil | Nécessaire pour |
|---|---|
| SDK Flutter | tout (Flutter Go le pilote, ne le remplace pas) |
| SDK Android + JDK 17 | compiler un APK, lancer sur Android |
| adb (Platform-Tools) | détecter un appareil USB ou Wi-Fi |
| macOS + Xcode | compiler/signer une app iOS — impossible depuis Windows |

### Depuis les sources

```bash
git clone https://github.com/emstronglezin-cmd/fluttergo.git
cd fluttergo/cli/fluttergo
dart pub get
dart pub global activate --source path .
```

### Compiler l'installateur soi-même (Windows)

Prérequis : SDK Dart, SDK Flutter, [Inno Setup 6](https://jrsoftware.org/isinfo.php).

```powershell
# 1. CLI : pub get + analyse + tests + binaire natif + test de démarrage
powershell -ExecutionPolicy Bypass -File scripts\build_windows.ps1

# 2. Desktop : analyse + tests + build Windows Release + test de démarrage
powershell -ExecutionPolicy Bypass -File scripts\build_gui_windows.ps1

# 3. Installateur + archive portable, dans dist\
powershell -ExecutionPolicy Bypass -File scripts\package_windows.ps1

# 4. Vérification de bout en bout (installation silencieuse, contrôles, désinstallation)
powershell -ExecutionPolicy Bypass -File scripts\verify_installation.ps1 `
    -Artifact dist\FlutterGo-Setup-<version>.exe -Uninstall
```

Les scripts échouent si les numéros de version divergent entre le CLI, la
Desktop et le tag Git : une build livrée ne peut pas afficher une version qui
n'existe pas.

## Utilisation du CLI

```bash
fluttergo doctor            # diagnostic de l'environnement
fluttergo devices           # appareils connectés
cd mon_projet_flutter
fluttergo run               # lancement + Hot Reload automatique
```

### Sans câble (Wi-Fi)

```bash
fluttergo wifi                        # première fois, en USB : bascule TCP/IP
fluttergo wifi pair <ip>:<port>       # Android 11+ : code d'appairage
fluttergo wifi connect <ip>           # connexions suivantes
```

### Installer l'app par QR code

```bash
cd mon_projet_flutter
fluttergo share
```

Le CLI compile l'APK, démarre un serveur local et affiche un QR code avec
l'adresse IP du poste (jamais `localhost`). Le téléphone, sur le même Wi-Fi,
scanne, télécharge et installe.

### Travailler à plusieurs sur un appareil

```bash
fluttergo host                                  # sur le PC relié à l'appareil
fluttergo join <ip>:<port> --token <jeton>      # sur le PC de chaque coéquipier
fluttergo join <ip>:<port> --token <jeton> --watch   # + envoi auto de lib/
```

### iPhone : installer une fois depuis macOS, développer depuis Windows

```bash
flutter run -d <iphone>   # sur le Mac, une seule fois par projet
fluttergo attach          # ensuite, depuis Windows, en Wi-Fi
```

## Plateformes — état réel

| Plateforme | CLI | Desktop |
|---|---|---|
| Windows 10/11 | ✅ | ✅ |
| macOS / Linux | ✅ (Dart pur) | — (Desktop est Windows-only) |
| Android USB / émulateur | ✅ | ✅ |
| Web (Chrome / Edge) | ✅ | ✅ |
| iOS — build et signature | ❌ exige macOS (contrainte Apple) | ❌ |
| iOS — développement quotidien | ✅ `fluttergo attach` après une installation initiale depuis macOS | ✅ |
| Windows (Hot Reload depuis un autre PC) | via `fluttergo run` | — |

## Limites assumées

- Flutter Go **pilote** le SDK Flutter officiel : aucune magie, aucun fork.
- Compiler ou signer une app iOS depuis Windows est impossible (Apple).
- Le partage APK exige que le téléphone soit sur le même réseau local ;
  certains hotspots isolent les clients entre eux.
- Le serveur de partage ne publie pas de compteur de téléchargements.
- Aucune télémétrie : Flutter Go n'envoie aucune donnée.

## Tests

```bash
# CLI (61 tests) — analyse statique et tests unitaires + intégration HTTP
cd cli/fluttergo && dart pub get && dart analyze && dart test

# Flutter Go Desktop (46 tests) — modèles, widgets, et rendu des 10 écrans
# à trois largeurs de fenêtre (aucun débordement toléré)
cd gui && flutter pub get && flutter analyze && flutter test

# Portail d'abonnement (17 tests)
cd web && npm ci && npm test
```

Guide détaillé, y compris la vérification de l'installateur :
[docs/COMMENT-TESTER.md](docs/COMMENT-TESTER.md).

## Documentation

| Document | Contenu |
|---|---|
| [docs/MANUEL.md](docs/MANUEL.md) | installation, usage, dépannage |
| [docs/GUI-FLUTTER-DESKTOP.md](docs/GUI-FLUTTER-DESKTOP.md) | architecture de l'application Desktop |
| [docs/COMMENT-TESTER.md](docs/COMMENT-TESTER.md) | exécuter les tests, vérifier un installateur |
| [brand/GUIDELINES.md](brand/GUIDELINES.md) | identité visuelle et emplacements de la marque |
| [docs/DUE_DILIGENCE.md](docs/DUE_DILIGENCE.md) | dossier de cession (périmètre, actifs, état vérifié) |
| [SECURITY.md](SECURITY.md) | modèle de menaces et signalement |
| [CHANGELOG.md](CHANGELOG.md) | historique des versions |

## Portail d'abonnement (`web/`)

Le portail Flutter Go Pro (inscription, session serveur, redirection vers le
checkout SasPay) vit dans `web/`. Aucune donnée de carte n'est stockée par
Flutter Go, et le montant est imposé côté serveur.

```bash
cd web
npm install
cp .env.example .env
npm start
```

Le contrat marchand SasPay doit être confirmé avant toute mise en production :
voir [web/README.md](web/README.md).

## Contribuer

Les issues et pull requests sont bienvenues. Avant de proposer un changement :

```bash
cd cli/fluttergo && dart analyze && dart test
cd ../../gui && flutter analyze && flutter test
```

## Licence

[MIT](LICENSE) — utilisation, modification et redistribution libres, y compris
commerciales, sous réserve de conserver la mention de copyright.
