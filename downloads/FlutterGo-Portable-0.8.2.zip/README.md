# Flutter Go 🚀

**L'expérience « Expo Go » pour Flutter.** Une CLI simple qui donne à vos projets
Flutter un cycle de développement instantané : détection d'environnement,
liste des appareils, et **Hot Reload automatique** dès que vous sauvegardez.

> 100 % gratuit et open source (licence MIT).

## Fonctionnalités

- `fluttergo doctor` — diagnostic complet de votre environnement
  (Flutter, Dart, ADB, Android SDK, licences, toolchain iOS)
- `fluttergo devices` — liste vos appareils connectés (mobiles, Chrome, Edge…)
- `fluttergo run` — lance votre app avec **Hot Reload automatique**
  sur un ou PLUSIEURS appareils simultanément (watcher intelligent,
  reconnexion auto par appareil) + Hot Restart global 🔥
- **Reconnexion automatique** — débranchez votre téléphone en plein session :
  Flutter Go attend son retour et relance tout seul (Phase 5) 🔁
- **Connexion Wi-Fi sans câble** — `fluttergo wifi` bascule votre téléphone en
  mode sans fil en une commande ; ensuite, plus jamais de câble 📶
- **Installation par QR code** — `fluttergo share` compile votre app et
  affiche un QR code : scannez-le sur le téléphone, elle s'installe.
  L'expérience « Expo Go », sans rien installer sur le téléphone 📲
- **Mode équipe** — `fluttergo host` / `fluttergo join` : toute l'équipe
  travaille en même temps sur LE même appareil, chaque modification de
  chacun apparaît instantanément 👥
- **Mode attach (iPhone sans Mac au quotidien)** — `fluttergo attach` se
  connecte à une app déjà installée sur l'appareil (une seule fois depuis
  macOS) et pilote Hot Reload directement depuis Windows, par Wi-Fi 📡

## Installation

> 📥 **Téléchargement public** : l'installateur Windows officiel est disponible
> sur le site Flutter Go — <https://emstronglezin-cmd.github.io/fluttergo-site/>
> (avec sommes de contrôle SHA-256 et le manuel PDF).

> 📖 Un **manuel complet d'installation et d'utilisation** est disponible dans
> [docs/MANUEL.md](docs/MANUEL.md) (constat de `doctor`, Wi-Fi, QR code,
> mode équipe, iPhone, portail Pro, dépannage).

### Windows (installateur — recommandé)

1. Téléchargez `FlutterGo-Setup-<version>.exe` depuis le
   [site Flutter Go](https://emstronglezin-cmd.github.io/fluttergo-site/)
   (ou, en tant que collaborateur, depuis les
   [Releases GitHub](https://github.com/emstronglezin-cmd/fluttergo/releases))
2. Double-cliquez sur l'installateur
3. **Rien à choisir** — l'installateur ajoute automatiquement `fluttergo` au PATH
   utilisateur et crée un raccourci Menu Démarrer (décochable)
4. Terminez l'installation
5. **Ouvrez un NOUVEAU terminal** (PowerShell, CMD ou Windows Terminal)
6. Vérifiez :

```powershell
fluttergo --version
fluttergo doctor
```

Détails de l'installateur :

- Installation **par utilisateur** dans `%LOCALAPPDATA%\Programs\FlutterGo`
  — **aucun droit administrateur requis**
- Le PATH **utilisateur** est modifié automatiquement (jamais le PATH système),
  sans créer de doublons
- Entrée de désinstallation propre dans « Applications installées » de Windows
  (la désinstallation retire aussi l'entrée PATH ajoutée)
- Si le PATH n'est pas pris en compte dans un terminal déjà ouvert, ouvrez-en un nouveau

Une archive portable `FlutterGo-Portable-<version>.zip` (juste `fluttergo.exe`,
aucun installateur) est aussi publiée à chaque release.

#### Dépannage Windows

| Problème | Solution |
|---|---|
| `fluttergo : commande introuvable` | Ouvrez un **nouveau** terminal : les terminaux déjà ouverts ne voient pas le PATH mis à jour. Sinon, relancez l'installateur : l'ajout au PATH utilisateur est automatique et idempotent. |
| PATH toujours pas pris en compte | Déconnectez/reconnectez votre session Windows, ou vérifiez `HKCU\Environment\Path` (doit contenir `%LOCALAPPDATA%\Programs\FlutterGo`). |
| `[FAIL] Flutter SDK not found` dans `fluttergo doctor` | Installez le [SDK Flutter](https://docs.flutter.dev/get-started/install/windows) et assurez-vous que `flutter` est sur votre PATH. Flutter Go pilote le SDK officiel, il ne le remplace pas. |
| `[FAIL] Android SDK` | Installez Android Studio (ou les command-line tools), puis `flutter config --android-sdk <chemin>` et définissez `ANDROID_HOME`. |
| `ADB` indisponible / 0 device | Vérifiez le câble et le « Débogage USB » sur le téléphone ; `adb devices` doit lister l'appareil. Vous pouvez pointer un adb précis via la variable `FLUTTERGO_ADB`. |

> Note : l'installateur installe **Flutter Go uniquement**. Les SDK de
> développement (Flutter, Android, Java) ne sont pas embarqués : `fluttergo doctor`
> les détecte et vous dit exactement ce qui manque.

### Depuis les sources

Prérequis : [SDK Dart](https://dart.dev/get-dart) ≥ 3.5

```bash
git clone https://github.com/emstronglezin-cmd/fluttergo.git
cd fluttergo/cli/fluttergo
dart pub get
dart pub global activate --source path .
```

La commande `fluttergo` est alors disponible partout dans votre terminal.

### Compiler l'installateur soi-même (Windows)

Prérequis : SDK Dart + [Inno Setup 6](https://jrsoftware.org/isinfo.php)
(`choco install innosetup` ou `winget install JRSoftware.InnoSetup`).

```powershell
# 1. Build du binaire natif (pub get + analyze + tests + compile + smoke test)
powershell -ExecutionPolicy Bypass -File scripts\build_windows.ps1

# 2. Packaging (installateur + zip portable dans dist\)
powershell -ExecutionPolicy Bypass -File scripts\package_windows.ps1

# 3. Vérification de bout en bout (install silencieuse + checks + désinstallation)
powershell -ExecutionPolicy Bypass -File scripts\verify_installation.ps1 `
    -Artifact dist\FlutterGo-Setup-<version>.exe -Uninstall
```

## Utilisation

```bash
# Vérifier votre environnement
fluttergo doctor

# Lister les appareils
fluttergo devices

# Lancer votre app avec Hot Reload automatique
cd mon_projet_flutter
fluttergo run
```

### Sans câble (Wi-Fi)

```bash
# Première fois : branchez le téléphone en USB une seule fois
fluttergo wifi            # passe le téléphone en mode Wi-Fi et s'y connecte

# Ensuite, débranchez le câble — tout se fait par le réseau :
fluttergo run

# Android 11+ (sans aucun câble du tout) :
fluttergo wifi pair <ip>:<port>     # code d'appairage affiché sur le téléphone
fluttergo wifi connect <ip>
```

Modifiez un fichier dans `lib/` → l'app se recharge instantanément. ✨

### Installer l'app sur un téléphone via QR code

```bash
cd mon_projet_flutter
fluttergo share
```

1. La CLI compile l'APK debug et affiche un QR code dans le terminal
2. Scannez-le avec le téléphone (même Wi-Fi que le PC)
3. Téléchargez et installez — c'est tout, rien à installer sur le téléphone

> Astuce : `fluttergo share --no-build` réutilise le dernier APK compilé.
> Le SDK Android est nécessaire sur le PC pour compiler (pas sur le téléphone).

### Travail d'équipe sur un appareil partagé

```bash
# Sur le PC connecté à l'appareil partagé (le "host") :
fluttergo host
# → affiche une commande à partager, ex. :
#   fluttergo join 192.168.1.5:51234 --token AbCdEf123456

# Sur le PC de chaque coéquipier (même réseau) :
fluttergo join 192.168.1.5:51234 --token AbCdEf123456          # logs live + reload à la demande
fluttergo join 192.168.1.5:51234 --token AbCdEf123456 --watch  # + push auto de vos modifs lib/
```

Avec `--watch` : chaque coéquipier édite son propre code localement ;
dès qu'il sauvegarde, ses fichiers sont poussés vers l'hôte et l'app se
recharge sur l'appareil partagé. Tout le monde voit tout, en temps réel.

### iPhone : un Mac une fois, Windows tous les jours

Le build/signature iOS exige macOS (contrainte Apple). Mais ensuite,
**plus besoin du Mac** :

```bash
# 1. Sur le Mac (une seule fois par projet) :
flutter run -d <iphone>        # installe l'app debug signée sur l'iPhone

# 2. De retour sur Windows, tous les jours :
cd mon_projet_flutter
fluttergo attach               # découvre l'app sur le réseau et s'y connecte
```

L'app tourne, vous modifiez `lib/` → Hot Reload instantané sur l'iPhone,
directement depuis Windows. Limites : toute modification native (plugins,
permissions) exige un nouveau build → retour Mac ; avec un compte Apple
gratuit l'app expire au bout de 7 jours (365 jours avec le compte payant).

## Plateformes supportées

| Plateforme | Statut |
|---|---|
| Web (Chrome/Edge) | ✅ Validé |
| Android (USB / émulateur) | ✅ Supporté |
| iOS — Hot Reload depuis Windows | ✅ `fluttergo attach` (après install initiale depuis macOS) |
| iOS — build/signature | ⚠️ Exige macOS + Xcode (contrainte Apple), une fois par projet |
| macOS / Linux | ✅ La CLI fonctionne (Dart pur) |

## Comment ça marche ?

Flutter Go pilote le daemon officiel de Flutter (`flutter run --machine`
et `flutter attach --machine`) : aucune magie obscure, aucun fork du SDK.
Le watcher surveille vos fichiers `.dart`, envoie les commandes
`app.restart` au daemon et affiche les logs.

## Feuille de route

- [x] Reconnexion automatique (débrancher/rebrancher sans relancer)
- [x] Pairing Wi-Fi sans câble (`fluttergo wifi`)
- [x] Installation depuis un QR code (`fluttergo share`)
- [x] Multi-appareils simultanés (`fluttergo run --all`)
- [x] Mode attach iPhone depuis Windows (`fluttergo attach`)
- [ ] Validation réelle de la boucle iPhone ↔ Windows sur matériel Apple
- [ ] Hot Reload sans fil sur l'APK partagé (rechargement à distance)
- [ ] Logs enrichis (filtres, recherche)

## Contribuer

Les PR sont bienvenues ! Ouvrez une issue pour discuter d'une fonctionnalité.

```bash
cd cli/fluttergo
dart analyze   # doit être propre
dart test      # tests unitaires
```

## Flutter Go Pro et portail d'abonnement

Le portail externe de Flutter Go se trouve dans [web](web/). Il propose un
abonnement Pro à **1 EUR par mois**, avec inscription, connexion, session
serveur et redirection vers le checkout SasPay. Les données de carte ne sont
jamais stockées par Flutter Go.

```bash
cd web
npm install
cp .env.example .env
npm start
```

Avant la production, renseignez le contrat marchand SasPay dans `web/.env` :
`SASPAY_CHECKOUT_URL`, ou `SASPAY_API_URL` avec `SASPAY_API_KEY`, ainsi que
`SASPAY_WEBHOOK_SECRET`. Le serveur impose le prix côté backend et traite les
webhooks de manière idempotente. Voir [web/README.md](web/README.md) pour le
déploiement Render manuel, la différence preview/production et les
vérifications à demander à SasPay.

## Licence

[MIT](LICENSE) — utilisez-le, modifiez-le, partagez-le librement.
